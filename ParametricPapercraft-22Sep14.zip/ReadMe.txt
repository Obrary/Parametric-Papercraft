Product: Parametric Papercraft, September 2014

Designer: Simon Kirkby

Support:  http://forums.obrary.com/category/designs/parametric-papercraft

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary is a marketplace of products collaboratively designed by the community. These products can be produced by anyone, amateur or professional manufacturer, wherever economically or locally practical.

Description:
Here's a Python app that creates designs for boxes to be cut from paper or cardboard by a Laser Cutter.